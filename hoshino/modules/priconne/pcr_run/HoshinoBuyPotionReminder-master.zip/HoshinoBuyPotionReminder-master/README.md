# Hoshino Buy Potion Reminder

pcr 药水购买提醒小助手

src目录下的文件直接覆盖到Hoshino根目录下即可